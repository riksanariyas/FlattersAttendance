<?php
$servername = "localhost";
$username = "root";
$password = "";
$start_date=$_REQUEST["start_date"];
$end_date=$_REQUEST["end_date"];
$punch_in_time=$_REQUEST["punch_in_time"];
$punch_out_time=$_REQUEST["punch_out_time"];
$emp_id=$_REQUEST["emp_id"];
  $status=$_REQUEST["status"];


// Create connection
$conn = new mysqli($servername, $username, $password,"company_database");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$ins="insert into attendence(start_date,end_date,punch_in_time,punch_out_time,emp_id,status) values('$start_date','$end_date','$punch_in_time','$punch_in_time','$emp_id','$status')";
echo $ins;
$conn->query($ins);

$conn->close();



echo "Connected successfully";
?>

