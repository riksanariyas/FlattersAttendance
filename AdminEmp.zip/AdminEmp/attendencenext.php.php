<?php
$servername = "localhost";
$username = "root";
$password = "";
$emp_name=$_REQUEST["emp_name"];
$emp_id=$_REQUEST["emp_id"];
$emp_dept=$_REQUEST["emp_dept"];
$emp_dob=$_REQUEST["emp_dob"];
$emp_address=$_REQUEST["emp_address"];
  $emp_mail=$_REQUEST["emp_email"];


// Create connection
$conn = new mysqli($servername, $username, $password,"company_database");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$ins="insert into emp_details(emp_name,emp_id,emp_dept,emp_dob,emp_address,emp_mail) values('$emp_name','$emp_id','$emp_dept','$emp_dob','$emp_address','$emp_mail')";
echo $ins;
$conn->query($ins);

$conn->close();



echo "Connected successfully";
?>

