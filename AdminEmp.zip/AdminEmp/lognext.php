<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$usename=$_REQUEST["usename"];
$pass=$_REQUEST["pass"];

// Create connection
$conn = new mysqli($servername, $username, $password,"company_database");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql="select * from log_deatils where usename='$usename' and pass = '$pass'";
$result = mysqli_query($conn, $sql);
if($row=mysqli_fetch_array($result))
{
	$_SESSION["uid"]=$usename;
	$ut=$row[2];
	if($ut=="Admin")
	{
		header("Location:adminuse.php");
	}
	else{
		header("Location:Empuse.php");
		
	}
	
	
	
}
else
{
	header("Location:nouse.php");

}

$conn->close();



echo "Connected successfully";
?>

