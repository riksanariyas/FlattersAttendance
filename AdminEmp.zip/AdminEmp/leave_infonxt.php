<?php
$servername = "localhost";
$username = "root";
$password = "";
$leave_id=$_REQUEST["leave_id"];
$leave_catagory=$_REQUEST["leave_cat"];
$no_of_leaves=$_REQUEST["no_leave"];



// Create connection
$conn = new mysqli($servername, $username, $password,"company_database");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$ins="insert into leave_info(leave_id,leave_catagory,no_of_leaves) values('$leave_id','$leave_catagory','$no_of_leaves')";
echo $ins;
$conn->query($ins);

$conn->close();



echo "Connected successfully";
?>

